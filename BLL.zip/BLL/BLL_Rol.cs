﻿using DAL;
using Servicio;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace BLL
{
    public class BLL_Rol
    {
        private DAL_Rol dal;
        private BLL_BitacoraEvento bllBitacora = new BLL_BitacoraEvento();
      
        public BLL_Rol()
        {
            string conn = "Data Source=.;Initial Catalog=BD_CuentaClara;Integrated Security=True;Encrypt=True;Trust Server Certificate=True";
            dal = new DAL_Rol(conn);

        }

        public void CrearRol(Servicio_Familia rol, List<string> idFamilias, List<string> idPermisos)
        {
            if (string.IsNullOrWhiteSpace(rol.Nombre))
                throw new Exception("Ingrese un nombre.");

            if (dal.ExisteNombre(rol.Nombre))
                throw new Exception("Ya existe un rol con ese nombre.");

            int totalElementos = (idFamilias != null ? idFamilias.Count : 0) + (idPermisos != null ? idPermisos.Count : 0);
            if (totalElementos < 1)
            {
                throw new Exception("Un Rol no puede crearse vacío. Debe asignarle al menos un Permiso o una Familia.");
            }

            List<string> permisosVistos = new List<string>();
            List<string> nombresRedundantes = new List<string>();
            BLL_Familia bllFam = new BLL_Familia();

            // A. Analizamos todas las Familias seleccionadas
            if (idFamilias != null)
            {
                foreach (string idFam in idFamilias)
                {
                    Servicio_Familia famCompleta = bllFam.ObtenerFamiliaCompleta(idFam);
                    // Reutilizamos tu método privado para aplanar todos los permisos de esta familia
                    List<Servicio_Permiso> permisosDeEstaFamilia = ObtenerPermisosDeFamiliaRecursivo(famCompleta);

                    foreach (Servicio_Permiso p in permisosDeEstaFamilia)
                    {
                        if (permisosVistos.Contains(p.IdRol))
                        {
                            if (!nombresRedundantes.Contains(p.Nombre)) nombresRedundantes.Add(p.Nombre);
                        }
                        else
                        {
                            permisosVistos.Add(p.IdRol);
                        }
                    }
                }
            }

            if (idPermisos != null)
            {
                foreach (string idPerm in idPermisos)
                {
                    if (permisosVistos.Contains(idPerm))
                    {
                        throw new Exception("Error de integridad: Ha seleccionado permisos sueltos que ya están incluidos dentro de las familias seleccionadas. Cancele y revise su selección.");
                    }
                    permisosVistos.Add(idPerm);
                }
            }


            if (nombresRedundantes.Count > 0)
            {
                throw new Exception("No se puede crear el Rol. Las familias seleccionadas tienen los siguientes permisos cruzados/redundantes: " + string.Join(", ", nombresRedundantes));
            }

            dal.CrearRol(rol.IdRol, rol.Nombre);

  
            if (idFamilias != null)
            {
                foreach (string idFam in idFamilias)
                {
                    this.AsignarFamiliaARol(rol.IdRol, idFam, false);
                }
            }

            if (idPermisos != null)
            {
                foreach (string idPerm in idPermisos)
                {
                    this.AsignarPermiso(rol.IdRol, idPerm);
                }
            }
            bllBitacora.RegistrarBitacora("Alta Perfil (Rol): " + rol.Nombre, SessionManager.GetInstancia().GetUsuarioActual().Login, "Gestión de Perfiles y Autorización", 2);
        }


        public List<Servicio_Familia> ObtenerRoles()
        {
            return dal.ListarRoles();
        }

        public void AsignarPermiso(string idRol, string idPermiso)

        {
            if (string.IsNullOrWhiteSpace(idRol)) throw new Exception("Seleccione un rol.");
                

            if (string.IsNullOrWhiteSpace(idPermiso)) throw new Exception("Seleccione un permiso.");
                

            if (dal.ExistePermiso(idRol, idPermiso)) throw new Exception("El rol ya posee ese permiso.");

            dal.AsignarPermiso(idRol, idPermiso);
            bllBitacora.RegistrarBitacora("Permiso asignado al Rol ID: " + idRol, SessionManager.GetInstancia().GetUsuarioActual().Login, "Gestión de Perfiles y Autorización", 2);

        }

        public string ObtenerNombreRol(string idRol)
        {
            return dal.ObtenerNombreRol(idRol);
        }

        public bool TienePermiso(string idRol, string idPermiso)
        {
            return dal.ExistePermiso(idRol, idPermiso);
        }
        public string VerificarRedundanciasRol(string idRol, string idFamilia)
        {
            BLL_Familia bllFam = new BLL_Familia();
            Servicio_Familia familiaCompleta = bllFam.ObtenerFamiliaCompleta(idFamilia);
            List<string> redundantes = new List<string>();

            if (familiaCompleta != null && familiaCompleta.ObtenerHijos() != null)
            {
                foreach (Servicio_Rol itemHijo in familiaCompleta.ObtenerHijos())
                {
                    if (!(itemHijo is Servicio_Familia))
                    {
                        if (this.TienePermiso(idRol, itemHijo.IdRol))
                        {
                            redundantes.Add(itemHijo.Nombre);
                        }
                    }
                }
            }

            return string.Join(", ", redundantes);      // Devuelve los nombres separados por coma (ej: "Crear Usuario, Editar Usuario")
        }
        public void AsignarFamiliaARol(string idRol, string idFamilia, bool limpiarRedundancias)

        {
            if (string.IsNullOrWhiteSpace(idRol))
                throw new Exception("Seleccione un rol.");

            if (string.IsNullOrWhiteSpace(idFamilia))
                throw new Exception("Seleccione una familia.");

            if (dal.ExisteFamilia(idRol, idFamilia))

            {
                throw new Exception("La familia ya está asignada.");

            }

            BLL_Familia bllFam = new BLL_Familia();
            Servicio_Familia familiaCompleta = bllFam.ObtenerFamiliaCompleta(idFamilia);

            List<string> permisosRedundantes = new List<string>();
            if (familiaCompleta != null && familiaCompleta.ObtenerHijos() != null)
            {
                foreach (Servicio_Rol itemHijo in familiaCompleta.ObtenerHijos())
                {
                    if (!(itemHijo is Servicio_Familia))
                    {
                        if (this.TienePermiso(idRol, itemHijo.IdRol))
                        {
                            permisosRedundantes.Add(itemHijo.Nombre);
                            
                        }
                    }
                }
            }
            if (permisosRedundantes.Count > 0)
            {
                string mensaje = "No se puede asignar la familia porque el rol ya posee los siguientes permisos: "
                                 + string.Join(", ", permisosRedundantes) + ".";
                throw new Exception(mensaje);
            }

            dal.AsignarFamilia(idRol, idFamilia);
            bllBitacora.RegistrarBitacora("Asignación de familias a rol", SessionManager.GetInstancia().GetUsuarioActual().Login, "Gestión de Perfiles y Autorización", 2);

        }


        public List<Servicio_Familia> ObtenerFamiliasPorRol(string idRol)

        {
            return dal.ObtenerFamiliasPorRol(idRol);

        }
        public void DesasignarPermiso(string idRol, string idPermiso)
        {

            dal.DesasignarPermiso(idRol, idPermiso);
            bllBitacora.RegistrarBitacora("Permiso desasignado del Rol ID: " + idRol, SessionManager.GetInstancia().GetUsuarioActual().Login, "Gestión de Perfiles y Autorización", 2);
        }

        public void DesasignarFamilia(string idRol, string idFamilia)
        {
            dal.DesasignarFamilia(idRol, idFamilia);
            bllBitacora.RegistrarBitacora("Familia desasignada del Rol ID: " + idRol, SessionManager.GetInstancia().GetUsuarioActual().Login, "Gestión de Perfiles y Autorización", 2);
        }

        public void ModificarRol(string idRol, string nombre)
        {
            if (string.IsNullOrWhiteSpace(idRol))
                throw new Exception("Seleccione un perfil.");

            if (string.IsNullOrWhiteSpace(nombre))
                throw new Exception("Ingrese un nombre.");

            dal.ModificarRol(idRol, nombre);
            bllBitacora.RegistrarBitacora("Modificación de Rol: " + nombre, SessionManager.GetInstancia().GetUsuarioActual().Login, "Gestión de Perfiles y Autorización", 2);
        }

        public void EliminarRol(string idRol)
        {
            if (string.IsNullOrWhiteSpace(idRol)) throw new Exception("Seleccione un Rol.");

            string nombre = ObtenerNombreRol(idRol);
            dal.EliminarRelacionesRol(idRol);

            dal.EliminarRol(idRol);
            bllBitacora.RegistrarBitacora("Baja de Rol: " + nombre, SessionManager.GetInstancia().GetUsuarioActual().Login, "Gestión de Perfiles y Autorización", 2);
        }

        public bool ExisteNombre(string nombre)
        {
            return dal.ExisteNombre(nombre);
        }
        public bool RolTienePermisoRecursivo(string idRol, string idPermiso)
        {

            if (TienePermiso(idRol, idPermiso)) return true;

            List<Servicio_Familia> familiasDelRol = ObtenerFamiliasPorRol(idRol);

            if (familiasDelRol != null)
            {
                BLL_Familia bllFam = new BLL_Familia();


                foreach (Servicio_Familia familia in familiasDelRol)
                {

                    string idFamilia = familia.IdRol;

                    Servicio_Familia famCompleta = bllFam.ObtenerFamiliaCompleta(idFamilia);

                    if (FamiliaContienePermiso(famCompleta, idPermiso))
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        private bool FamiliaContienePermiso(Servicio_Familia familia, string idPermisoBuscado)
        {
            if (familia != null && familia.ObtenerHijos() != null)
            {
                foreach (Servicio_Rol hijo in familia.ObtenerHijos())
                {
                    if (hijo is Servicio_Familia subFamilia)
                    {

                        if (FamiliaContienePermiso(subFamilia, idPermisoBuscado)) return true;
                    }
                    else
                    {

                        if (hijo.IdRol == idPermisoBuscado) return true;
                    }
                }
            }
            return false;
        }


        public bool ValidarPermisoEnArbol(Servicio_Rol componente, string idPermisoBuscado)
        {
            return ValidarRecursivo(componente, idPermisoBuscado, 0);
        }

        public bool EsRedundanteAsignar(string idRol, string idFamiliaHija)
        {
     
            List<Servicio_Familia> familiasDelRol = dal.ObtenerFamiliasPorRol(idRol);
            BLL_Familia bllFam = new BLL_Familia();

            foreach (Servicio_Familia familiaEnRol in familiasDelRol)
            {
             
                if (familiaEnRol.IdRol == idFamiliaHija) return true;
                Servicio_Familia famCompleta = bllFam.ObtenerFamiliaCompleta(familiaEnRol.IdRol);
                if (FamiliaContieneFamilia(famCompleta, idFamiliaHija))
                {
                    return true;
                }
            }
            return false;
        }

        private bool ValidarRecursivo(Servicio_Rol componente,  string permisoBuscado, int profundidad)
        {
            if (profundidad > 10) return false;

            if (componente == null) return false;

            if (string.Equals(componente.IdRol, permisoBuscado, StringComparison.OrdinalIgnoreCase) ||
                string.Equals(componente.Nombre, permisoBuscado, StringComparison.OrdinalIgnoreCase))
            {
                return true;
            }

            if (componente is Servicio_Familia familia)
            {
                foreach (Servicio_Rol hijo in familia.ObtenerHijos())
                {
                    if (ValidarRecursivo(hijo, permisoBuscado, profundidad + 1))
                        return true;
                }
            }

            return false;
        }

        private bool FamiliaContieneFamilia(Servicio_Familia familia, string idFamiliaBuscada)
        {
            if (familia != null && familia.ObtenerHijos() != null)
            {
                foreach (Servicio_Rol hijo in familia.ObtenerHijos())
                {
                    if (hijo is Servicio_Familia subFamilia)
                    {
                        if (subFamilia.IdRol == idFamiliaBuscada) return true;
                        if (FamiliaContieneFamilia(subFamilia, idFamiliaBuscada)) return true;
                    }
                }
            }
            return false;
        }

        public bool ExisteRedundanciaPermisos(string idRol, string idFamiliaNueva)
        {
           
            BLL_Familia bllFam = new BLL_Familia();
            Servicio_Familia familiaNueva = bllFam.ObtenerFamiliaCompleta(idFamiliaNueva);
 
            List<Servicio_Permiso> listaPermisos = ObtenerPermisosDeFamiliaRecursivo(familiaNueva);

            foreach (var permiso in listaPermisos)
            {
                if (this.RolTienePermisoRecursivo(idRol, permiso.IdRol))
                {
                    return true; // Existe redundancia
                }
            }
            return false;
        }

        // Método auxiliar para aplanar la jerarquía de la familia
        private List<Servicio_Permiso> ObtenerPermisosDeFamiliaRecursivo(Servicio_Familia familia)
        {
            List<Servicio_Permiso> lista = new List<Servicio_Permiso>();
            foreach (var hijo in familia.ObtenerHijos())
            {
                if (hijo is Servicio_Permiso p) lista.Add(p);
                else if (hijo is Servicio_Familia f) lista.AddRange(ObtenerPermisosDeFamiliaRecursivo(f));
            }
            return lista;
        }
    }
}